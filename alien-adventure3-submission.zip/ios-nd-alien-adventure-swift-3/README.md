<img src="https://s3-us-west-1.amazonaws.com/udacity-content/degrees/catalog-images/nd003.png" alt="iOS Developer Nanodegree logo" height="70" >

# Alien Adventure

![Platform iOS](https://img.shields.io/badge/nanodegree-iOS-blue.svg)

This repository contains starter code for the Alien Adventure project in Udacity's iOS Nanodegree.

## Overview

Alien Adventure is an intergalactic "click-to-continue" game. The game's main robot protagonist needs your help answering  questions posed by aliens who block its path.

## Setup

Each question posed by an alien has an associated Swift file where you "implement" a response. Otherwise, there are no special setup instructions, just build, run, and click!

## Maintainers

@jarrodparkes


